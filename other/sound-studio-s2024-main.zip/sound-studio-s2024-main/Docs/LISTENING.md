# Sound Studio Mixtape

Pierre Schaeffer, [Études des bruits](https://www.youtube.com/watch?v=CTf0yE15zzI) (1948)

Newman Guttman, [The Silver Scale](https://www.youtube.com/watch?v=PM64-lqYyZ8) (1957)

Iannis Xenakis, [Concret PH](https://www.youtube.com/watch?v=XsOyxFybxPY&t=54s) (1958)

Ligeti, György [Artikulation](https://www.youtube.com/watch?v=71hNl_skTZQ)(1958)

Luciano Berio, [Thema - Ommagio a Joyce](https://www.youtube.com/watch?v=jV_76OZSsqo) (1958)

Max Mathews & Joan Miller, [Bicycle Built For Two](https://www.youtube.com/watch?v=ZFUVR-clo8g) (1961)

Morton Subotnick, [Silver Apples of The Moon](https://www.youtube.com/watch?v=3G1hRNLlYpg) (1967)

Alice Shields, [The Transformation of Ani](https://www.youtube.com/watch?v=7yOS_6sCkkU) (1970)

Suzanne Ciani, [Buchla Concerts](https://www.youtube.com/watch?v=f5Ji2Me6JhM&t=1690s&ab_channel=%E2%83%9D) (1975)

Laurie Spiegel, [The Expanding Universe](https://www.youtube.com/watch?v=KD8hkveKmYQ) (1980)

Charanjit Singh, [Ten Ragas to a Disco Beat](https://www.youtube.com/watch?v=BN8M2irJVJA&t=235s&ab_channel=RonaldGrinder) (1982)

Jean-Claude Risset, [Sud](https://www.youtube.com/watch?v=Fhj2O4jToKI) (1985)

Éliane Radigue, [Jetsun Mila](https://www.youtube.com/watch?v=oneBG6N0_uY) (1987)

Paul Lansky, [Night Traffic](https://www.youtube.com/watch?v=7WL0J3kJEmk&t=437s) (1990)

Brad Garton, [Rough Raga Riffs](http://sites.music.columbia.edu/brad/music/mp3/Rough_Raga_Riffs.mp3) (1991)

John Oswald, [Plexure](https://www.youtube.com/watch?v=3eZQq9ebtEg) (1993)

Natasha Barrett, [Racing Unseen](https://www.youtube.com/watch?v=3QW9V70yXQQ) (1996)

Judy Klein, [The Wolves of Bays Mountain](http://sites.bxmc.poly.edu/~lukedubois/download/wolves.mp3) (1998)

Cher, [Believe](https://www.youtube.com/watch?v=n7wvAEDOxAs) (1998)

Curtis Roads, [Half-Life](https://www.youtube.com/watch?v=8D5ObNnHgck) (1999)

Rob Clouth, [Transition](https://www.youtube.com/watch?v=kdxFymtNt_w) (2018)

Ryoichi Kurokawa, [ad/ab Atom](https://www.youtube.com/watch?v=bvHiobhVfnw) (2020)

Leafcutter John, [Gritstone Improvisation One](https://www.youtube.com/watch?v=AoI8T6epJF4) (2023)

Keith Fullerton Whitman, [190303.Graz](https://www.youtube.com/watch?v=m2oDexNiI0c&list=OLAK5uy_nU8nHOGMiSNGQYYS3vjB39t7ew1lhLYXI), (2023)

SPIME.IM and Akasha, [Hint](https://www.youtube.com/watch?v=X5HZ2cCigMU), (2023)

sv1, [₂₀₂₃₁₂₃₁ ₁₄₅](https://www.youtube.com/watch?v=ydtAzMbydgQ) (2023)

Mark Fell - Multistability
Floating Points + Pharoah Sanders - Promises
Rob Clouth - Zero Point
Flying Lotus - Cosmogramma
Amon Tobin - ISAM
Aphex Twin - Drukqs
Tim Hecker - Virgins
Oneohtrix Point Never - R Plus Seven
Venetian Snares - Traditional Synthesizer Music